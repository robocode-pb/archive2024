#ifndef Score_h
#define Score_h

#include <avr/pgmspace.h>
#include <Arduino.h>
#include "GameBoy.h"


const uint8_t one[] PROGMEM = {
  0b00000000,
  0b00001000,
  0b00011000,
  0b00101000,
  0b00001000,
  0b00001000,
  0b00111110,
  0b00000000,
};

const uint8_t two[] PROGMEM = {
  0b00000000,
  0b00011100,
  0b00100010,
  0b00000100,
  0b00001000,
  0b00010000,
  0b00111110,
  0b00000000,
};

const uint8_t three[] PROGMEM = {
  0b00000000,
  0b00111110,
  0b00000100,
  0b00001000,
  0b00011100,
  0b00000010,
  0b00000010,
  0b00111100,
  0b00000000,
};

const uint8_t four[] PROGMEM = {
  0b00000000,
  0b00100010,
  0b00100010,
  0b00100010,
  0b00111110,
  0b00000010,
  0b00000010,
  0b00000000,
};
const uint8_t five[] PROGMEM = {
  0b00000000,
  0b00111110,
  0b00100000,
  0b00111100,
  0b00000010,
  0b00000010,
  0b00111100,
  0b00000000,
};
const uint8_t six[] PROGMEM = {
  0b00000000,
  0b00001110,
  0b00010000,
  0b00111100,
  0b00100010,
  0b00100010,
  0b00011100,
  0b00000000,
};

const uint8_t seven[] PROGMEM = {
  0b00000000,
  0b00111110,
  0b00000100,
  0b00001000,
  0b00010000,
  0b00100000,
  0b00100000,
  0b00000000,
};

const uint8_t eight[] PROGMEM = {
  0b00000000,
  0b00011100,
  0b00100010,
  0b00011100,
  0b00100010,
  0b00100010,
  0b00011100,
  0b00000000,
};

const uint8_t nine[] PROGMEM = {
  0b00000000,
  0b00011100,
  0b00100010,
  0b00100010,
  0b00011110,
  0b00000010,
  0b00011100,
  0b00000000,
};

const uint8_t zero[] PROGMEM = {
  0b00000000,
  0b00011100,
  0b00100010,
  0b00100010,
  0b00100010,
  0b00100010,
  0b00011100,
  0b00000000,
};


const uint8_t *const numbers[] PROGMEM = {zero, one, two, three, four, five, six, seven, eight, nine};

void drawScore(GameBoy gb, uint8_t number) {
  number = number > 99 ? 99 : number < 0 ? 0 : number;
  int8_t digit1 = number < 10 ? number : number / 10;
  int8_t digit2 = number < 10 ? -1 : number % 10;
  uint8_t* ptr1 = (uint8_t *)pgm_read_ptr(&(numbers[digit1]));
  uint8_t* ptr2 = digit2 >= 0 ? (uint8_t *)pgm_read_ptr(&(numbers[digit2])) : nullptr;

  for (int i = 0; i < 16; ++i) {
    uint8_t line;
    if (i < 8) line = pgm_read_byte_near(ptr1 + i);
    else line = digit2 < 0 ? 0 : pgm_read_byte_near(ptr2 + (i - 8));
    for (int j = 0; j < 7; ++j) {
      gb.setLed(j, i, (line >> 7 - j) & 1);
    }
  }
}

#endif  //GameBoy.h
